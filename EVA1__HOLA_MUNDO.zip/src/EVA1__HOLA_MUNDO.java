/** primera practica de java. Defincion de nomenclatrua para practicas

*@author Jorge Alberto Gallegos Gomez 
* */
public class EVA1__HOLA_MUNDO {

    /**
     * @param args the command line arguments
     */

    public static void main(String[] args) {
        // Primer linea de codigo
        System.out.println("Hola");
        System.out.println("Hola Mundo"); //printin --> imprime menaje
    
  }
    
    
}
